package publicpakage2;
import publicpakage1.*;

public class publicclass2 {

	public static void main(String[] args) {
		publicclass1 obj = new publicclass1(); 
        obj.display();  

		// TODO Auto-generated method stub

	}

}
