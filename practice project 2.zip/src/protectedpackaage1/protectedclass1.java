package protectedpackaage1;

public class protectedclass1 {

	protected void display() 
    { 
        System.out.println("protected access specifier"); 
    } 


}
