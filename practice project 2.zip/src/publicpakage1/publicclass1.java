package publicpakage1;

public class publicclass1 {
	public void display() 
    { 
        System.out.println("This is Public Access Specifiers"); 
    } 


}
