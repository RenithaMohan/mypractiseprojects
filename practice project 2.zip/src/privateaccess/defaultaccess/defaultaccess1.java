package defaultaccess;

class defaultaccess1 {
	void display() 
    { 
        System.out.println("defalut access"); 
    } 

}
