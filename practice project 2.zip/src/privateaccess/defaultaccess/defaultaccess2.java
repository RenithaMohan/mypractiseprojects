package defaultaccess;

public class defaultaccess2 {

	public static void main(String[] args) {
			//default
			System.out.println("Dafault Access Specifier");
			defaultaccess1 obj = new defaultaccess1(); 		  
	        obj.display(); 


		// TODO Auto-generated method stub

	}

}
