package privateaccess;

public class privateaccess1 {

	   private void display() 
	    { 
	        System.out.println("private access"); 
	    } 


}
