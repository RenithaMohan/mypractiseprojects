package privateaccess;

public class privateacess2 {

	public static void main(String[] args) {
		System.out.println("Private Access Specifier");
		privateaccess1  obj = new privateaccess1(); 
        //trying to access private method of another class 
        //obj.display();

	}

		// TODO Auto-generated method stub

	}


