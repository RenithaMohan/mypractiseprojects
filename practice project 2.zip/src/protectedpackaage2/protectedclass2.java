package protectedpackaage2;
import protectedpackaage1.*;
public class protectedclass2 extends protectedclass1{

	public static void main(String[] args) {
		protectedclass2 obj = new protectedclass2 ();   
		obj.display();  

		// TODO Auto-generated method stub

	}

}
