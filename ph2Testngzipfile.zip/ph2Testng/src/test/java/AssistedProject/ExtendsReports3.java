package AssistedProject;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtendsReports3 {
	@Test
	public void ExtentreporDemo3() throws IOException
	{


		ExtentReports ex = new ExtentReports();
	    File file = new File("report.html");
		ExtentSparkReporter sparkreporter = new ExtentSparkReporter(file);
	    ex.attachReporter(sparkreporter); // report gets created
	
	    // test cases whose status will be captured in the report
	   
	    ExtentTest test1 = ex.createTest("Test1");
	    test1.pass("Test Case passed");
	   
	    ExtentTest test2 = ex.createTest("Test2");
	   test2.log(Status.FAIL, "This test has failed");
	   
	    ExtentTest test3 = ex.createTest("Test3");
	    test3.skip("This test has skipped");
	   
	    ExtentTest test4 = ex.createTest("Test4");
	    test4.fail("This test has failed");
  
	ex.flush();
	Desktop.getDesktop().browse(new File("report.html").toURI());
	}


}
