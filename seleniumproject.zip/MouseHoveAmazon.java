package phase1selenium;

public class MouseHoveAmazon {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
