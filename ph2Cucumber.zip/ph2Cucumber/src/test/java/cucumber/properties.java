package cucumber;

public class properties {

}
