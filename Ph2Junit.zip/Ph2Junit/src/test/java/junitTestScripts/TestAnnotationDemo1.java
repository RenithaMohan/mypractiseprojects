package junitTestScripts;

import org.junit.Test;

public class TestAnnotationDemo1 {


	@Test
	public void method1()
	{
		System.out.println("Hello Junit");
	}
}
