package junitTestScripts;

public class Calculator {
	public int add(int n1, int n2)
	{
		int total = n1+n2;
		return total;
	}

}




