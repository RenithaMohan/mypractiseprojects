package junitTestScripts;

public class TestDemo1 {

}
